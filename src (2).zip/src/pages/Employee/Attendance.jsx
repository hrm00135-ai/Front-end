import { useState } from "react";

const Attendance = () => {
  const [attendance] = useState([]);

  const today = {
    status: "Present",
    checkIn: "09:10 AM",
    checkOut: "06:05 PM",
  };

  const summary = {
    present: 22,
    absent: 2,
    leaves: 3,
    percentage: 92,
  };

  const getStatusStyle = (status) => {
    switch (status) {
      case "Present":
        return "bg-green-100 text-green-700";
      case "Absent":
        return "bg-red-100 text-red-700";
      case "Late":
        return "bg-yellow-100 text-yellow-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <div className="p-4 w-full">

      {/* 🔹 Title */}
      <h1 className="text-xl sm:text-2xl font-bold mb-6">
        Attendance
      </h1>

      {/* 🔹 Today Card */}
      <div className="bg-white border rounded-xl p-4 shadow-sm mb-6">
        <h2 className="font-semibold mb-3">Today</h2>

        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">

          <div>
            <span className={`px-3 py-1 text-xs rounded-full ${getStatusStyle(today.status)}`}>
              {today.status}
            </span>

            <p className="text-sm text-gray-500 mt-2">
              Check In: {today.checkIn}
            </p>

            <p className="text-sm text-gray-500">
              Check Out: {today.checkOut}
            </p>
          </div>

          {/* Buttons */}
          <div className="flex gap-2">
            <button className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm">
              Check In
            </button>
            <button className="bg-red-500 text-white px-4 py-2 rounded-lg text-sm">
              Check Out
            </button>
          </div>
        </div>
      </div>

      {/* 🔹 Summary Cards (same style as tasks grid) */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-6">

        <div className="bg-white border rounded-xl p-4 shadow-sm">
          <p className="text-sm text-gray-500">Present</p>
          <p className="text-xl font-bold mt-1">{summary.present}</p>
        </div>

        <div className="bg-white border rounded-xl p-4 shadow-sm">
          <p className="text-sm text-gray-500">Absent</p>
          <p className="text-xl font-bold mt-1">{summary.absent}</p>
        </div>

        <div className="bg-white border rounded-xl p-4 shadow-sm">
          <p className="text-sm text-gray-500">Leaves</p>
          <p className="text-xl font-bold mt-1">{summary.leaves}</p>
        </div>

        <div className="bg-white border rounded-xl p-4 shadow-sm">
          <p className="text-sm text-gray-500">Attendance %</p>
          <p className="text-xl font-bold mt-1 text-blue-600">
            {summary.percentage}%
          </p>
        </div>

      </div>

      {/* 🔹 History (TASK STYLE CARDS) */}
      <div>
        <h2 className="font-semibold mb-4">History</h2>

        {attendance.length === 0 ? (
          <div className="bg-white border rounded-xl p-6 text-center text-gray-500">
            No attendance records
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {attendance.map((item, index) => (
              <div
                key={index}
                className="border rounded-xl p-4 shadow-sm bg-white"
              >
                <p className="font-semibold">{item.date}</p>

                <p className="text-sm text-gray-500 mt-1">
                  In: {item.checkIn}
                </p>

                <p className="text-sm text-gray-500">
                  Out: {item.checkOut}
                </p>

                <span
                  className={`inline-block mt-2 px-2 py-1 text-xs rounded-full ${getStatusStyle(item.status)}`}
                >
                  {item.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};

export default Attendance;